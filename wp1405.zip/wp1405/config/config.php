<?php
return array (
  'db_host' => 'localhost',
  'db_name' => 'ir123486_wp1405',
  'db_user' => 'ir123486_wp1405',
  'db_pass' => '1vN-@K-GMkl@3-rR',
);
