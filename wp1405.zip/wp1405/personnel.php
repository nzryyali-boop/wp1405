<?php
declare(strict_types=1);
session_start();
if (empty($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (($_SESSION['role'] ?? '') !== 'admin') { http_response_code(403); exit('دسترسی فقط برای مدیر سامانه مجاز است.'); }
require __DIR__ . '/db.php';

/* Additive migration: existing records are preserved. */
$cols = $pdo->query("SHOW COLUMNS FROM personnel")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('national_id', $cols, true)) {
    $pdo->exec("ALTER TABLE personnel ADD COLUMN national_id VARCHAR(20) NULL AFTER personnel_code");
}
if (!in_array('default_site_id', $cols, true)) {
    $pdo->exec("ALTER TABLE personnel ADD COLUMN default_site_id BIGINT UNSIGNED NULL AFTER default_project_id");
}
if (empty($_SESSION['csrf_personnel'])) $_SESSION['csrf_personnel'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_personnel'];
$message = '';
$errors = [];
$imported = 0;
$updated = 0;

function readXlsxRows(string $path): array {
    if (!class_exists('ZipArchive')) throw new RuntimeException('افزونه PHP ZipArchive روی هاست فعال نیست؛ فایل را در Excel با فرمت CSV UTF-8 ذخیره و بارگذاری کنید.');
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) throw new RuntimeException('فایل XLSX باز نشد.');
    $shared = [];
    $sharedXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($sharedXml !== false) {
        $sx = simplexml_load_string($sharedXml, 'SimpleXMLElement', LIBXML_NONET);
        if ($sx) foreach ($sx->xpath('//*[local-name()="si"]') as $si) {
            $text = '';
            foreach ($si->xpath('.//*[local-name()="t"]') as $t) $text .= (string)$t;
            $shared[] = $text;
        }
    }
    $sheet = $zip->getFromName('xl/worksheets/sheet1.xml');
    if ($sheet === false) { $zip->close(); throw new RuntimeException('برگهٔ اول فایل اکسل پیدا نشد.'); }
    $sx = simplexml_load_string($sheet, 'SimpleXMLElement', LIBXML_NONET);
    if (!$sx) { $zip->close(); throw new RuntimeException('ساختار فایل اکسل معتبر نیست.'); }
    $rows = [];
    foreach ($sx->xpath('//*[local-name()="sheetData"]/*[local-name()="row"]') as $rowNode) {
        $row = [];
        foreach ($rowNode->xpath('./*[local-name()="c"]') as $cell) {
            $ref = (string)$cell['r'];
            preg_match('/^[A-Z]+/', $ref, $m);
            $letters = $m[0] ?? 'A';
            $index = 0;
            for ($i=0; $i<strlen($letters); $i++) $index = $index * 26 + (ord($letters[$i]) - 64);
            $index--;
            $type = (string)$cell['t'];
            $value = '';
            if ($type === 'inlineStr') {
                foreach ($cell->xpath('.//*[local-name()="t"]') as $t) $value .= (string)$t;
            } else {
                $v = $cell->xpath('./*[local-name()="v"]');
                $raw = isset($v[0]) ? (string)$v[0] : '';
                $value = ($type === 's') ? ($shared[(int)$raw] ?? '') : $raw;
            }
            $row[$index] = trim($value);
        }
        if ($row) {
            $max = max(array_keys($row));
            $normalized = [];
            for ($i=0; $i<=$max; $i++) $normalized[] = $row[$i] ?? '';
            $rows[] = $normalized;
        }
    }
    $zip->close();
    return $rows;
}
function readCsvRows(string $path): array {
    $fh = fopen($path, 'rb');
    if (!$fh) throw new RuntimeException('فایل CSV خوانده نشد.');
    $first = fgets($fh);
    if ($first === false) { fclose($fh); return []; }
    $delimiter = (substr_count($first, ';') > substr_count($first, ',')) ? ';' : ',';
    rewind($fh);
    $rows = [];
    while (($r = fgetcsv($fh, 0, $delimiter)) !== false) {
        if (isset($r[0])) $r[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$r[0]);
        $rows[] = array_map(static fn($v) => trim((string)$v), $r);
    }
    fclose($fh);
    return $rows;
}
$headerNames = ['شماره پرسنلی','کد ملی','نام','نام خانوادگی','گروه شیفت','نام پروژه','نام سایت','گروه شغلی','فعال'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
        $errors[] = 'درخواست معتبر نیست؛ صفحه را تازه‌سازی کنید.';
    } elseif (!isset($_FILES['personnel_file']) || $_FILES['personnel_file']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'فایل را انتخاب کنید و دوباره تلاش کنید.';
    } elseif ($_FILES['personnel_file']['size'] > 5 * 1024 * 1024) {
        $errors[] = 'حجم فایل باید کمتر از ۵ مگابایت باشد.';
    } else {
        $tmp = $_FILES['personnel_file']['tmp_name'];
        $ext = strtolower(pathinfo($_FILES['personnel_file']['name'], PATHINFO_EXTENSION));
        try {
            if ($ext === 'xlsx') $rows = readXlsxRows($tmp);
            elseif ($ext === 'csv') $rows = readCsvRows($tmp);
            else throw new RuntimeException('فقط فایل XLSX یا CSV UTF-8 پذیرفته می‌شود.');
            if (count($rows) < 2) throw new RuntimeException('فایل عنوان ستون‌ها و دست‌کم یک ردیف پرسنل داشته باشد.');
            $headers = array_map(static fn($v) => trim((string)$v), $rows[0]);
            if (isset($headers[0])) $headers[0] = preg_replace('/^\xEF\xBB\xBF/', '', $headers[0]);
            if ($headers !== $headerNames) throw new RuntimeException('عنوان ستون‌ها با قالب استاندارد یکسان نیست. از فایل قالب ارائه‌شده استفاده کنید و عنوان‌ها را تغییر ندهید.');
            $projectStmt = $pdo->prepare('SELECT id FROM projects WHERE name=? AND is_active=1 LIMIT 1');
            $siteStmt = $pdo->prepare('SELECT id FROM sites WHERE project_id=? AND name=? AND is_active=1 LIMIT 1');
            $groupStmt = $pdo->prepare('SELECT id FROM job_groups WHERE name=? AND is_active=1 LIMIT 1');
            $existsStmt = $pdo->prepare('SELECT id FROM personnel WHERE personnel_code=? LIMIT 1');
            $prepared = []; $seen = [];
            for ($line=2; $line<count($rows)+1; $line++) {
                $r = $rows[$line-1];
                $r = array_pad(array_slice($r, 0, 9), 9, '');
                if (count(array_filter($r, static fn($v) => trim((string)$v) !== '')) === 0) continue;
                [$code,$nid,$first,$last,$shift,$project,$site,$group,$active] = array_map(static fn($v) => trim((string)$v), $r);
                if ($code === '' || $first === '' || $last === '') { $errors[] = "ردیف $line: شماره پرسنلی، نام و نام خانوادگی الزامی است."; continue; }
                if (isset($seen[$code])) { $errors[] = "ردیف $line: شماره پرسنلی تکراری در همین فایل ($code)."; continue; }
                $seen[$code] = true;
                if ($shift !== '' && !in_array(strtoupper($shift), ['A','B','C'], true)) { $errors[] = "ردیف $line: گروه شیفت باید A یا B یا C باشد."; continue; }
                $projectId = null;
                if ($project !== '') {
                    $projectStmt->execute([$project]); $projectId = $projectStmt->fetchColumn();
                    if (!$projectId) { $errors[] = "ردیف $line: پروژه «$project» در سامانه پیدا نشد."; continue; }
                }
                $siteId = null;
                if ($site !== '') {
                    if (!$projectId) { $errors[] = "ردیف $line: برای تعیین سایت، نام پروژه را هم وارد کنید."; continue; }
                    $siteStmt->execute([$projectId, $site]); $siteId = $siteStmt->fetchColumn();
                    if (!$siteId) { $errors[] = "ردیف $line: سایت «$site» برای این پروژه پیدا نشد."; continue; }
                }
                $groupId = null;
                if ($group !== '') {
                    $groupStmt->execute([$group]); $groupId = $groupStmt->fetchColumn();
                    if (!$groupId) { $errors[] = "ردیف $line: گروه شغلی «$group» در سامانه پیدا نشد."; continue; }
                }
                $activeValue = 1;
                if (in_array(strtolower($active), ['خیر','نه','no','0','غیرفعال'], true)) $activeValue = 0;
                elseif ($active !== '' && !in_array(strtolower($active), ['بله','آری','yes','1','فعال'], true)) { $errors[] = "ردیف $line: ستون فعال باید بله یا خیر باشد."; continue; }
                $existsStmt->execute([$code]);
                $oldId = $existsStmt->fetchColumn();
                $prepared[] = ['code'=>$code,'nid'=>($nid===''?null:$nid),'first'=>$first,'last'=>$last,'shift'=>($shift===''?null:strtoupper($shift)),'project'=>$projectId?:null,'site'=>$siteId?:null,'group'=>$groupId?:null,'active'=>$activeValue,'old_id'=>$oldId?:null,'line'=>$line];
            }
            if (!$prepared && !$errors) throw new RuntimeException('هیچ ردیف پرسنلی برای ورود پیدا نشد.');
            if (!$errors) {
                $pdo->beginTransaction();
                $ins = $pdo->prepare('INSERT INTO personnel (personnel_code,national_id,first_name,last_name,job_group_id,default_project_id,default_site_id,shift_group,is_active) VALUES (?,?,?,?,?,?,?,?,?)');
                $upd = $pdo->prepare('UPDATE personnel SET national_id=?,first_name=?,last_name=?,job_group_id=?,default_project_id=?,default_site_id=?,shift_group=?,is_active=? WHERE id=?');
                foreach ($prepared as $p) {
                    if ($p['old_id']) {
                        $upd->execute([$p['nid'],$p['first'],$p['last'],$p['group'],$p['project'],$p['site'],$p['shift'],$p['active'],$p['old_id']]);
                        $updated++;
                    } else {
                        $ins->execute([$p['code'],$p['nid'],$p['first'],$p['last'],$p['group'],$p['project'],$p['site'],$p['shift'],$p['active']]);
                        $imported++;
                    }
                }
                $pdo->commit();
                $message = "ورود موفق بود: $imported پرسنل جدید و $updated رکورد به‌روزرسانی شد.";
            } else {
                $message = 'به‌دلیل وجود خطا، هیچ ردیفی وارد نشد. خطاها را اصلاح و دوباره بارگذاری کنید.';
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $errors[] = $e instanceof RuntimeException ? $e->getMessage() : 'خطا هنگام پردازش فایل. ساختار دیتابیس و نام ستون‌ها را بررسی کنید.';
        }
    }
}
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود گروهی پرسنل</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="wide"><header><div><h1>ورود گروهی پرسنل</h1><p>بارگذاری یک‌جای فهرست کارکنان از اکسل</p></div><a href="dashboard.php">بازگشت به داشبورد</a></header>
<p class="note">قالب اکسل باید ۹ ستون استاندارد داشته باشد. نام پروژه، سایت و گروه شغلی باید دقیقاً مطابق اطلاعات ثبت‌شده در سامانه باشند. شماره پرسنلی تکراری به‌جای ایجاد رکورد جدید، به‌روزرسانی می‌شود.</p>
<?php if($message):?><div class="note"><?=h($message)?></div><?php endif;?>
<?php if($errors):?><div class="error"><strong>موارد نیازمند اصلاح:</strong><ul><?php foreach($errors as $e):?><li><?=h($e)?></li><?php endforeach;?></ul></div><?php endif;?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><label>فایل پرسنل (XLSX یا CSV UTF-8)<input type="file" name="personnel_file" accept=".xlsx,.csv" required></label><button class="btn" type="submit">بررسی و ورود پرسنل</button></form>
<p><a href="قالب_ورود_پرسنل.xlsx">دریافت قالب اکسل</a></p>
</main></body></html>
