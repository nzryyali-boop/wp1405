<?php
declare(strict_types=1);
$configFile = __DIR__ . '/config/config.php';
if (!file_exists($configFile)) { header('Location: install.php'); exit; }
$config = require $configFile;
$pdo = new PDO('mysql:host='.$config['db_host'].';dbname='.$config['db_name'].';charset=utf8mb4', $config['db_user'], $config['db_pass'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
