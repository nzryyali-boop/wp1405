CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 full_name VARCHAR(160) NOT NULL,
 role ENUM('admin','shift_supervisor','manager','deputy','president','employee') NOT NULL DEFAULT 'employee',
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 failed_attempts INT NOT NULL DEFAULT 0,
 locked_until DATETIME NULL,
 last_login_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS projects (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(160) NOT NULL UNIQUE,
 is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sites (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 project_id BIGINT UNSIGNED NOT NULL,
 name VARCHAR(160) NOT NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 FOREIGN KEY (project_id) REFERENCES projects(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS job_groups (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL UNIQUE,
 color VARCHAR(20) NOT NULL DEFAULT '#dbeafe',
 is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS personnel (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 personnel_code VARCHAR(60) NOT NULL UNIQUE,
 first_name VARCHAR(100) NOT NULL,
 last_name VARCHAR(100) NOT NULL,
 job_group_id BIGINT UNSIGNED NULL,
 default_project_id BIGINT UNSIGNED NULL,
 shift_group ENUM('A','B','C') NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 FOREIGN KEY (job_group_id) REFERENCES job_groups(id) ON DELETE SET NULL,
 FOREIGN KEY (default_project_id) REFERENCES projects(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS equipment (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 equipment_code VARCHAR(80) NOT NULL UNIQUE,
 name VARCHAR(160) NOT NULL,
 project_id BIGINT UNSIGNED NULL,
 site_id BIGINT UNSIGNED NULL,
 ownership ENUM('owned','contractor') NOT NULL DEFAULT 'owned',
 work_mode ENUM('hourly','service','both') NOT NULL DEFAULT 'both',
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
 FOREIGN KEY (site_id) REFERENCES sites(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS equipment_eligible_drivers (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 equipment_id BIGINT UNSIGNED NOT NULL,
 personnel_id BIGINT UNSIGNED NOT NULL,
 is_primary TINYINT(1) NOT NULL DEFAULT 0,
 UNIQUE KEY uq_equipment_driver (equipment_id, personnel_id),
 FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE,
 FOREIGN KEY (personnel_id) REFERENCES personnel(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS load_ids (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(60) NOT NULL UNIQUE,
 title VARCHAR(160) NOT NULL,
 origin VARCHAR(160) NULL,
 destination VARCHAR(160) NULL,
 tariff DECIMAL(14,2) NOT NULL DEFAULT 0,
 notes VARCHAR(500) NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS shifts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 project_id BIGINT UNSIGNED NOT NULL,
 shift_group ENUM('A','B','C') NOT NULL,
 shift_type ENUM('day','night') NOT NULL,
 shift_date DATE NOT NULL COMMENT 'Persian date should be converted by application; night shift date is start date',
 starts_at DATETIME NOT NULL,
 ends_at DATETIME NOT NULL,
 supervisor_user_id BIGINT UNSIGNED NULL,
 status ENUM('open','closed') NOT NULL DEFAULT 'open',
 closed_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_project_shift (project_id, shift_group, shift_type, shift_date),
 FOREIGN KEY (project_id) REFERENCES projects(id),
 FOREIGN KEY (supervisor_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS attendance (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 shift_id BIGINT UNSIGNED NOT NULL,
 personnel_id BIGINT UNSIGNED NOT NULL,
 status ENUM('present','absent','leave','sick','mission','disciplinary','other') NOT NULL,
 note VARCHAR(500) NULL,
 recorded_by BIGINT UNSIGNED NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_shift_person (shift_id, personnel_id),
 FOREIGN KEY (shift_id) REFERENCES shifts(id) ON DELETE CASCADE,
 FOREIGN KEY (personnel_id) REFERENCES personnel(id),
 FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS work_entries (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 shift_id BIGINT UNSIGNED NOT NULL,
 personnel_id BIGINT UNSIGNED NOT NULL,
 equipment_id BIGINT UNSIGNED NULL,
 work_mode ENUM('hourly','service') NOT NULL,
 productive_hours DECIMAL(5,2) NOT NULL DEFAULT 0,
 performance_score TINYINT UNSIGNED NULL,
 description VARCHAR(500) NULL,
 recorded_by BIGINT UNSIGNED NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (shift_id) REFERENCES shifts(id) ON DELETE CASCADE,
 FOREIGN KEY (personnel_id) REFERENCES personnel(id),
 FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE SET NULL,
 FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS work_services (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 work_entry_id BIGINT UNSIGNED NOT NULL,
 load_id BIGINT UNSIGNED NOT NULL,
 service_count DECIMAL(10,2) NOT NULL DEFAULT 0,
 FOREIGN KEY (work_entry_id) REFERENCES work_entries(id) ON DELETE CASCADE,
 FOREIGN KEY (load_id) REFERENCES load_ids(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS work_stoppages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 work_entry_id BIGINT UNSIGNED NOT NULL,
 hours DECIMAL(5,2) NOT NULL DEFAULT 0,
 reason ENUM('repair','other') NOT NULL DEFAULT 'other',
 description VARCHAR(500) NULL,
 FOREIGN KEY (work_entry_id) REFERENCES work_entries(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS monthly_closures (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 project_id BIGINT UNSIGNED NOT NULL,
 year_number SMALLINT UNSIGNED NOT NULL,
 month_number TINYINT UNSIGNED NOT NULL,
 closed_by BIGINT UNSIGNED NULL,
 closed_at DATETIME NOT NULL,
 UNIQUE KEY uq_project_month (project_id, year_number, month_number),
 FOREIGN KEY (project_id) REFERENCES projects(id),
 FOREIGN KEY (closed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 action VARCHAR(120) NOT NULL,
 entity_type VARCHAR(100) NULL,
 entity_id BIGINT UNSIGNED NULL,
 details TEXT NULL,
 ip_address VARCHAR(45) NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO projects (name) VALUES ('گل‌گهر'), ('جهان فولاد'), ('توسعه آهن');
INSERT IGNORE INTO job_groups (name, color) VALUES ('راننده کامیون','#d9f2d9'), ('راننده بیل مکانیکی','#fff0b3'), ('راننده لودر','#e2f0d9'), ('کنترل و سایر','#e9ddff');
