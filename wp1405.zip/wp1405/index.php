<?php
declare(strict_types=1);
session_start();
if (!file_exists(__DIR__.'/config/installed.lock')) { header('Location: install.php'); exit; }
require __DIR__.'/db.php';
$error='';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $username=trim($_POST['username']??''); $password=(string)($_POST['password']??'');
 $q=$pdo->prepare('SELECT * FROM users WHERE username=? LIMIT 1'); $q->execute([$username]); $u=$q->fetch();
 if (!$u || !$u['is_active'] || ($u['locked_until'] && strtotime($u['locked_until'])>time()) || !password_verify($password,$u['password_hash'])) {
  if ($u) { $attempt=(int)$u['failed_attempts']+1; $locked=$attempt>=3?date('Y-m-d H:i:s',time()+6*3600):null; $pdo->prepare('UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?')->execute([$locked?$attempt:($attempt%3),$locked,$u['id']]); }
  $error='ورود ناموفق است؛ اطلاعات را بررسی کنید یا در صورت قفل شدن با مدیر سامانه تماس بگیرید.';
 } else {
  $pdo->prepare('UPDATE users SET failed_attempts=0, locked_until=NULL, last_login_at=NOW() WHERE id=?')->execute([$u['id']]);
  session_regenerate_id(true); $_SESSION['user_id']=$u['id']; $_SESSION['full_name']=$u['full_name']; $_SESSION['role']=$u['role'];
  $pdo->prepare('INSERT INTO audit_logs (user_id,action,ip_address) VALUES (?,?,?)')->execute([$u['id'],'login',$_SERVER['REMOTE_ADDR']??null]); header('Location: dashboard.php'); exit;
 }
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود سامانه</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="box"><h1>سامانه ثبت کارکرد</h1><?php if($error):?><div class="error"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif;?><form method="post"><label>نام کاربری<input name="username" required autocomplete="username"></label><label>رمز عبور<input type="password" name="password" required autocomplete="current-password"></label><button class="btn">ورود</button></form><p class="note">اگر هنوز نصب نکرده‌اید، <a href="install.php">نصب سامانه</a>.</p></main></body></html>
