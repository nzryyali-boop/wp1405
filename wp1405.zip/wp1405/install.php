<?php
declare(strict_types=1);
session_start();
$error = '';
$done = false;
if (file_exists(__DIR__ . '/config/installed.lock')) {
    $done = true;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$done) {
    $host = trim($_POST['db_host'] ?? 'localhost');
    $db = trim($_POST['db_name'] ?? '');
    $dbUser = trim($_POST['db_user'] ?? '');
    $dbPass = (string)($_POST['db_pass'] ?? '');
    $adminUser = trim($_POST['admin_user'] ?? 'admin');
    $adminPass = (string)($_POST['admin_pass'] ?? '');
    $adminName = trim($_POST['admin_name'] ?? 'مدیر سامانه');
    if ($db === '' || $dbUser === '' || $adminUser === '' || strlen($adminPass) < 10) {
        $error = 'نام پایگاه داده، نام کاربری پایگاه داده و نام کاربری مدیر الزامی است. رمز مدیر باید حداقل ۱۰ نویسه باشد.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $db)) {
        $error = 'نام پایگاه داده فقط می‌تواند شامل حروف انگلیسی، عدد و زیرخط باشد.';
    } else {
        try {
            $pdo = new PDO("mysql:host={$host};dbname={$db};charset=utf8mb4", $dbUser, $dbPass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
            $schema = file_get_contents(__DIR__ . '/schema.sql');
            // This schema intentionally contains no stored procedures or semicolons inside string literals.
            foreach (preg_split('/;\s*(?:\r?\n|$)/', (string)$schema) as $statement) {
                $statement = trim($statement);
                if ($statement !== '') $pdo->exec($statement);
            }
            $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, full_name, role, is_active, failed_attempts) VALUES (?, ?, ?, ?, 1, 0)');
            $stmt->execute([$adminUser, password_hash($adminPass, PASSWORD_DEFAULT), $adminName, 'admin']);
            $config = "<?php\nreturn " . var_export(['db_host'=>$host,'db_name'=>$db,'db_user'=>$dbUser,'db_pass'=>$dbPass], true) . ";\n";
            if (!is_dir(__DIR__ . '/config')) mkdir(__DIR__ . '/config', 0750, true);
            if (file_put_contents(__DIR__ . '/config/config.php', $config, LOCK_EX) === false) throw new RuntimeException('امکان نوشتن فایل تنظیمات وجود ندارد. مجوز پوشه config را بررسی کنید.');
            file_put_contents(__DIR__ . '/config/installed.lock', date(DATE_ATOM), LOCK_EX);
            $done = true;
        } catch (Throwable $e) {
            $error = 'نصب انجام نشد: ' . $e->getMessage() . ' — مطمئن شوید پایگاه داده از قبل در هاست ساخته شده و کاربر آن مجوز ساخت جدول دارد.';
        }
    }
}
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نصب سامانه ثبت کارکرد</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="box"><h1>نصب سامانه ثبت کارکرد</h1>
<?php if ($done): ?><div class="ok"><h2>نصب انجام شد</h2><p>اکنون وارد صفحه ورود شوید و پس از ورود، این فایل install.php را از هاست حذف کنید.</p><a class="btn" href="index.php">رفتن به صفحه ورود</a></div>
<?php else: ?><p>ابتدا در کنترل‌پنل هاست یک پایگاه داده MySQL بسازید و مشخصات آن را اینجا وارد کنید.</p><?php if ($error): ?><div class="error"><?=h($error)?></div><?php endif; ?><form method="post"><label>میزبان پایگاه داده<input name="db_host" value="<?=h($_POST['db_host'] ?? 'localhost')?>" required></label><label>نام پایگاه داده<input name="db_name" value="<?=h($_POST['db_name'] ?? '')?>" required></label><label>کاربر پایگاه داده<input name="db_user" value="<?=h($_POST['db_user'] ?? '')?>" required></label><label>رمز پایگاه داده<input type="password" name="db_pass" autocomplete="new-password"></label><hr><label>نام مدیر سامانه<input name="admin_name" value="<?=h($_POST['admin_name'] ?? 'مدیر سامانه')?>" required></label><label>نام کاربری مدیر<input name="admin_user" value="<?=h($_POST['admin_user'] ?? 'admin')?>" required></label><label>رمز مدیر (حداقل ۱۰ نویسه)<input type="password" name="admin_pass" minlength="10" required autocomplete="new-password"></label><button class="btn" type="submit">نصب و ایجاد جداول</button></form><p class="note">نیازمندی: PHP 8.1 یا جدیدتر، افزونه PDO MySQL و پایگاه داده MySQL/MariaDB. رمزها به‌صورت هش ذخیره می‌شوند.</p><?php endif; ?></main></body></html>
